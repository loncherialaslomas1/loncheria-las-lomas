LONCHERÍA LAS LOMAS — ORDERING WEBSITE

This folder is a complete static website.
The ordering app is contained in index.html, including the black-and-white
linocut artwork and WhatsApp ordering.

EASIEST DEPLOYMENT:
1. Create a GitHub account if you do not already have one.
2. Create a new PUBLIC repository, for example:
   loncheria-las-lomas
3. Upload index.html to the top level of the repository.
4. In the repository, open Settings > Pages.
5. Select "Deploy from a branch", choose "main" and "/" (root), then Save.
6. GitHub will give you a public website address ending in github.io.

The website must have index.html at the top level.

After you have the public website address, create a new QR code that points
to that address. That QR code will open the ordering app instead of WhatsApp
directly.

IMPORTANT:
The app currently sends the completed order to:
WhatsApp +52 322 214 4231

For a real online ordering system later, we can add:
- custom domain
- order numbers
- kitchen order screen
- online payments
- delivery zones
- daily specials / sold-out products
- customer order history
